"""Check the declared synthetic API-to-pack result, not arbitrary accounts."""
import csv
import argparse
import hashlib
import io
import json
from pathlib import Path
from zipfile import ZipFile
from pypdf import PdfReader

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--lab', type=Path, default=Path('/private/tmp/shtops-paperless-lab-20261022/data'))
lab = parser.parse_args().lab
api = json.loads((lab / 'api-observations.json').read_text())
pack = lab / 'from-real-paperless-api.zip'
with ZipFile(pack) as archive:
    manifest = json.loads(archive.read('manifest.json'))
    rows = list(csv.DictReader(io.StringIO(archive.read('2026-10.csv').decode('utf-8-sig'))))
    pdf = archive.read('2026-10.pdf')
reader = PdfReader(io.BytesIO(pdf))
assert api['selected_query_count'] == manifest['expected_documents'] == manifest['documents'] == len(rows) == 2
assert len(reader.pages) == manifest['pdf_pages'] == 3
assert [(row['vendor'], row['total'], row['currency'], row['category'], row['pdf_start_page'], row['pdf_end_page']) for row in rows] == [
    ('Demo Supplies', '12.30', 'EUR', 'Supplies', '1', '2'),
    ('Demo Groceries', '7.07', 'EUR', 'Food', '3', '3'),
]
assert hashlib.sha256(pdf).hexdigest() == manifest['pdf_sha256']
for source in manifest['sources']:
    assert hashlib.sha256((lab / 'downloaded' / source['source_file']).read_bytes()).hexdigest() == source['sha256']
result = {
    'result': 'PASS', 'real_local_api_version': '3.3.3', 'synthetic_only': True,
    'server_selection_count': api['selected_query_count'], 'api_pages': api['api_pages'],
    'csv_rows': len(rows), 'pdf_pages': len(reader.pages), 'values_and_page_ranges': rows,
    'source_hashes_match': True, 'output_sha256': hashlib.sha256(pack.read_bytes()).hexdigest(),
    'pdf_sha256': manifest['pdf_sha256'], 'no_full_provider_or_OCR_claim': True,
}
(lab / 'end-to-end-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
