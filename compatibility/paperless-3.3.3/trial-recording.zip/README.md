# Local Paperless API compatibility trial

This is a one-off synthetic interoperability check, not a supported Paperless connector or provider deployment. The existing MIT receipt packer is unchanged.

On 22 October 2026 the author started a new isolated Paperless-ngx 3.3.3 / ARM64 Linux instance with SQLite and Valkey 9. The official application image digest was `sha256:dba0242c1df1843643df4eb50ce5639f3a7900f414879088fd5bed8eaf2d456d`. It had no previous documents or customer accounts. Only a temporary fixture directory was mounted; port 18766 was bound to 127.0.0.1.

The real API consumed four fictional PDFs dated September 30, October 1, October 31 and November 1. The trial supplied reviewed metadata, created monetary/string custom fields and correspondents, and retrieved them through authenticated HTTP. An October document-date query with page_size=1 returned two pages and the two expected documents in date order. Original downloads matched the uploaded fixtures byte for byte.

The unmodified packer processed the retrieved metadata/PDFs: two CSV rows, 12.30/7.07 EUR, Supplies/Food, page ranges 1-2/3-3, three PDF pages, matching source hashes. The merged PDF is byte-identical to the previously independently reviewed synthetic PDF. The first ad-hoc verifier mistakenly expected a `file` manifest key; that author verification error was corrected to the existing `source_file` contract. No packer defect or packer modification was involved.

## Inspect the recorded result

`observed/` contains safe recorded synthetic inputs/output, not server credentials or an instance snapshot. With Python and requirements.txt installed:

```sh
python verify_result.py --lab observed
python receipt_pack.py observed/from-api-reviewed.json observed/downloaded a-new-output.zip
```

Use a new output filename: the packer preserves existing files. `probe.py` is the exact author trial driver. It deliberately targets only the disposable loopback lab, requires a new empty instance and reads that lab's private test .env. Do not run it against a real archive or invent customer compatibility from this recording. The live lab will be stopped after evidence collection.

This checks one upstream version, one chosen date definition and two reviewed custom fields. It does not perform OCR or infer amounts/categories. It is not a ready upstream-exporter adapter, hosted-provider permission/configuration, interactive user workflow, arbitrary-version support, real printer/accountant acceptance or accounting completeness. The server query count is meaningful only for the chosen query and the four controlled inputs. No paid assignment or provider/business payment exists.

Official references: https://github.com/paperless-ngx/paperless-ngx/releases/tag/v3.3.3 and https://raw.githubusercontent.com/paperless-ngx/paperless-ngx/v3.3.3/docker/compose/docker-compose.sqlite.yml . No Paperless server source is bundled here. Authored with AI assistance; own probe/packer code is MIT.
