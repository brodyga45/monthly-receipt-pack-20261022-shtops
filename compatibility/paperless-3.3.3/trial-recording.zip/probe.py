"""One disposable, synthetic Paperless 3.3.3 API trial, not a supported adapter.

Runs only against the dedicated loopback lab. Does not accept remote URLs or
customer credentials. Existing receipt_pack.py remains the separate packer.
"""
import base64
import hashlib
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

LAB = Path('/private/tmp/shtops-paperless-lab-20261022/data')
BASE = 'http://127.0.0.1:18766'
settings = dict(line.split('=', 1) for line in (LAB / '.env').read_text().splitlines())
auth = base64.b64encode(('synthetic-lab:' + settings['PAPERLESS_LAB_PASSWORD']).encode()).decode()
observations = {'synthetic_only': True, 'base': BASE, 'scope': 'single local version; not customer acceptance'}


def request(path, *, method='GET', obj=None, fields=None, pdf=None, raw=False, authenticated=True):
    if path.startswith(BASE + '/'):
        path = path[len(BASE):]
    if not path.startswith('/api/'):
        raise ValueError('Only this dedicated loopback API is allowed')
    headers = {'Accept': 'application/json'}
    if authenticated:
        headers['Authorization'] = 'Basic ' + auth
    body = None
    if obj is not None:
        body = json.dumps(obj).encode()
        headers['Content-Type'] = 'application/json'
    if fields is not None:
        boundary = 'shtops-synthetic-lab-boundary'
        chunks = []
        for key, value in fields.items():
            chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode())
        if pdf:
            chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="document"; filename="{pdf.name}"\r\nContent-Type: application/pdf\r\n\r\n'.encode() + pdf.read_bytes() + b'\r\n')
        chunks.append(f'--{boundary}--\r\n'.encode())
        body = b''.join(chunks)
        headers['Content-Type'] = 'multipart/form-data; boundary=' + boundary
    req = urllib.request.Request(BASE + path, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            data = response.read()
            return data if raw else json.loads(data)
    except urllib.error.HTTPError as error:
        raise RuntimeError(f'{method} {path}: HTTP {error.code}: {error.read().decode()[:1200]}') from None


def main():
    start = time.monotonic()
    while True:
        try:
            initial = request('/api/documents/?page_size=1')
            break
        except (OSError, RuntimeError):
            if time.monotonic() - start > 150:
                raise
            time.sleep(2)
    assert initial['count'] == 0, 'Lab must be a new, empty instance'
    print('PASS new empty authenticated API', flush=True)
    try:
        request('/api/documents/', authenticated=False)
        raise AssertionError('Documents were unexpectedly public')
    except RuntimeError as error:
        assert 'HTTP 401' in str(error) or 'HTTP 403' in str(error), str(error)
    observations['anonymous_document_access'] = 'denied'

    totals = request('/api/custom_fields/', method='POST', obj={'name': 'Synthetic total', 'data_type': 'monetary'})
    categories = request('/api/custom_fields/', method='POST', obj={'name': 'Synthetic category', 'data_type': 'string'})
    suppliers = {}
    for name in ['Demo Supplies', 'Demo Groceries']:
        suppliers[name] = request('/api/correspondents/', method='POST', obj={'name': name})['id']
    fixture = json.loads((LAB / 'fixtures/reviewed.json').read_text())
    for doc in fixture['documents']:
        fields = {'title': 'LAB-' + doc['id'], 'created': doc['date']}
        if 'vendor' in doc:
            fields['correspondent'] = suppliers[doc['vendor']]
        request('/api/documents/post_document/', method='POST', fields=fields, pdf=LAB / 'fixtures' / doc['pdf'])
    print('Uploaded four fictional PDFs through the real consumer', flush=True)

    start = time.monotonic()
    while True:
        listed = request('/api/documents/?page_size=100')
        if listed['count'] == 4:
            break
        if time.monotonic() - start > 180:
            raise RuntimeError('Consumer did not produce four documents: ' + json.dumps(request('/api/tasks/'))[:2000])
        time.sleep(2)
    by_title = {row['title']: row for row in listed['results']}
    for doc in fixture['documents']:
        actual = by_title['LAB-' + doc['id']]
        assert actual['created'][:10] == doc['date'], (actual['title'], actual['created'])
        if 'total' in doc:
            request(f"/api/documents/{actual['id']}/", method='PATCH', obj={'custom_fields': [
                {'field': totals['id'], 'value': doc['currency'] + doc['total']},
                {'field': categories['id'], 'value': doc['category']},
            ]})
    print('PASS explicit document dates and reviewed custom fields', flush=True)

    query = '/api/documents/?' + urllib.parse.urlencode({'created__date__gte': '2026-10-01', 'created__date__lt': '2026-11-01', 'page_size': 1, 'ordering': 'created,id'})
    selected, pages, server_count = [], 0, None
    while query:
        page = request(query)
        if server_count is None:
            server_count = page['count']
        assert page['count'] == server_count
        selected.extend(page['results'])
        pages += 1
        assert pages <= 4, 'Unexpected pagination loop'
        query = page['next']
        if query:
            assert urllib.parse.urlsplit(query).netloc == '127.0.0.1:18766', 'Foreign pagination URL'
    assert server_count == len(selected) == 2
    assert pages == 2
    assert [x['title'] for x in selected] == ['LAB-oct-a', 'LAB-oct-b']
    print('PASS October boundaries, stable order and two real API pages', flush=True)

    target = LAB / 'downloaded'
    target.mkdir()
    normalised = []
    source_checks = []
    for row in selected:
        values = {field['field']: field['value'] for field in row['custom_fields']}
        amount = str(values[totals['id']])
        assert amount.startswith('EUR'), amount
        original = next(x for x in fixture['documents'] if 'LAB-' + x['id'] == row['title'])
        actual_vendor = request(f"/api/correspondents/{row['correspondent']}/")['name']
        assert actual_vendor == original['vendor'], 'Uploaded correspondent was not retained'
        pdf = request(f"/api/documents/{row['id']}/download/?original=true", raw=True)
        assert pdf.startswith(b'%PDF-')
        actual_hash = hashlib.sha256(pdf).hexdigest()
        fixture_hash = hashlib.sha256((LAB / 'fixtures' / original['pdf']).read_bytes()).hexdigest()
        assert actual_hash == fixture_hash, 'Original download differs from uploaded fixture'
        name = str(row['id']) + '.pdf'
        (target / name).write_bytes(pdf)
        normalised.append({'id': str(row['id']), 'date': row['created'][:10], 'vendor': actual_vendor, 'total': amount[3:], 'currency': amount[:3], 'category': values[categories['id']], 'pdf': name})
        source_checks.append({'id': row['id'], 'sha256': actual_hash, 'original_fixture_match': True})
    (LAB / 'from-api-reviewed.json').write_text(json.dumps({'month': '2026-10', 'expected_documents': server_count, 'documents': normalised}, indent=2) + '\n')
    observations.update({'documents_created': 4, 'selected_query_count': server_count, 'api_pages': pages, 'selected_titles': [x['title'] for x in selected], 'normalised_reviewed_metadata': normalised, 'downloaded_source_checks': source_checks, 'limitations': ['one synthetic local instance', 'not OCR/extraction', 'not hosted-provider permission or mapping', 'not an upstream adapter or supported deployment', 'not accounting completeness or a paid acceptance']})
    (LAB / 'api-observations.json').write_text(json.dumps(observations, indent=2) + '\n')
    print('PASS original PDF byte hashes and API-to-packer manifest', flush=True)


if __name__ == '__main__':
    main()
